﻿namespace streams
{
    internal class MainClass
	{
		public static void Main (string[] args)
		{
			
		}
	}
}
